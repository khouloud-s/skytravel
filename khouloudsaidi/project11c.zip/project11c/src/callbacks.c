#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"

void
on_quitter_rec_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget*reclamation_agent;
reclamation_agent=lookup_widget(objet,"reclamation_agent");
gtk_widget_destroy(reclamation_agent);
}


void
on_afficher_rec_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *reclamation_agent;
GtkWidget *treeviewrec;

reclamation_agent=lookup_widget(objet,"reclamation_agent");

reclamation_agent=create_reclamation_agent();
gtk_widget_show(reclamation_agent);

treeviewrec=lookup_widget(reclamation_agent,"treeviewrec");
afficher_reclamation(treeviewrec);
}


void
on_envoyer_rec_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data)
{
 reclamation r;
GtkWidget *input1;

GtkWidget *reclamation_agent;

reclamation_agent=lookup_widget(objet,"reclamation_agent");

input1=lookup_widget(objet,"reponse");


strcpy(r.reponse,gtk_entry_get_text(GTK_ENTRY (input1)));


ajouter_reponse(r);
}


void
on_repondre_rec_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{

}


void
on_treeviewrec_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)

{
gchar *str_data;
gchar *str_data1;
gchar *str_data2;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,1, &str_data1, -1);
  }
strcpy(r.cin,str_data);
strcpy(r.nom,str_data1);
}

