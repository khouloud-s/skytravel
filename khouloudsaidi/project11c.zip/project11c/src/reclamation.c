#include <stdio.h>
#include <string.h>
#include "reclamation.h"
#include <gtk/gtk.h>

enum
{    
          CIN,
          NOM,
          PRENOM,
          DATE,
          RECLAMATION,
          REPONSE,
          COLUMNS
};
void ajouter_reponse(reclamation r)
{
   FILE *f;
   f=fopen("reclamation.txt","a+");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s \n",r.cin,r.nom,r.prenom,r.date,r.reclamation,r.reponse)!=EOF)
{
if (strcmp(r.cin," ")==0)
{ 
fclose(f);}
else
{
 fprintf(f," %s   \n",r.reponse);
}
fclose(f);
}
}
void afficher_reclamation(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
   
    GtkTreeIter  iter;
   
   GtkListStore *store;
 
   char nom [30] ;
   char prenom [30] ;
   char date [30] ;
   char reclamation [3000] ;
   char reponse[3000] ;
   char cin [30] ;
   store=NULL ;
   FILE *f;
   store=gtk_tree_view_get_model(liste);
  if (store==NULL)
  {
     renderer = gtk_cell_renderer_text_new () ;
     column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text", CIN,NULL);
     gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column) ;
//*************
//*************
renderer = gtk_cell_renderer_text_new () ;
     column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text", NOM,NULL);
     gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column) ;

 renderer = gtk_cell_renderer_text_new () ;
     column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text", PRENOM,NULL);
     gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column) ;

renderer = gtk_cell_renderer_text_new () ;
     column = gtk_tree_view_column_new_with_attributes("date", renderer, "text", DATE,NULL);
     gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column) ;

renderer = gtk_cell_renderer_text_new () ;
     column = gtk_tree_view_column_new_with_attributes("reclamation", renderer, "text", RECLAMATION,NULL);
     gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column) ;
renderer = gtk_cell_renderer_text_new () ;
     column = gtk_tree_view_column_new_with_attributes("reponse", renderer, "text", REPONSE,NULL);
     gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column) ;
store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f = fopen("reclamation.txt","r");
if(f==NULL)
return;
else
{
f = fopen("reclamation.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s\n",cin,nom,prenom,date,reclamation,reponse)!=EOF)
{
gtk_list_store_append (store,&iter);

gtk_list_store_set (store,&iter,CIN,cin,NOM,nom,PRENOM,prenom,DATE,date,RECLAMATION,reclamation,REPONSE,reponse, -1);
}
 fclose(f);
 gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
 g_object_unref (store);
}
}
}
