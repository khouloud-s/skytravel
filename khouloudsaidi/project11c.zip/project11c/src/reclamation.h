#include <gtk/gtk.h>

typedef struct
{

char cin[20];
char nom[20];
char prenom[30];
char date[30];
char reclamation[3000];
char reponse [3000];
}reclamation;
void ajouter_reponse(reclamation r);
void afficher_reclamation(GtkWidget *liste);
