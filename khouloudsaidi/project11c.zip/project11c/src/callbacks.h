#include <gtk/gtk.h>


void
on_quitter_rec_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_afficher_rec_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_envoyer_rec_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_repondre_rec_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_treeviewrec_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
