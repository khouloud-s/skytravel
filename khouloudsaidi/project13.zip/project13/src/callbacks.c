#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "excursionclient.h"


void
on_afficherex_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget *excursion_client;
GtkWidget *treeview1;

excursion_client=lookup_widget(objet,"excursion_client");
gtk_widget_show(excursion_client);

treeview1=lookup_widget(excursion_client,"treeview1");
afficher_client_ex(treeview1);
}


void
on_ajouter_cl_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{
 Client c;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *excursion_client;

excursion_client=lookup_widget(objet,"excursion_client");

input1=lookup_widget(objet,"cin");
input2=lookup_widget(objet,"nom");
input3=lookup_widget(objet,"pays");
input5=lookup_widget(objet,"dt_d");
input6=lookup_widget(objet,"dt_a");
input4=lookup_widget(objet,"destination");

strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY (input1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY (input2)));
strcpy(c.pays,gtk_entry_get_text(GTK_ENTRY (input3)));
strcpy(c.destination,gtk_entry_get_text(GTK_ENTRY (input4)));
strcpy(c.dt_d,gtk_entry_get_text(GTK_ENTRY (input5)));
strcpy(c.dt_a,gtk_entry_get_text(GTK_ENTRY (input6)));

ajouter_client_ex(c);
}


void
on_quitter_ex_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *excursion_client;

excursion_client=lookup_widget(objet,"excursion_client");

gtk_widget_destroy(excursion_client);
}


