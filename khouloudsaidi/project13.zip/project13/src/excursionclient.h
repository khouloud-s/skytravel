#include <gtk/gtk.h>

typedef struct
{

char cin[8];
char nom[20];
char pays[30];
char dt_d[30];
char dt_a[30];
char destination[10];

}Client;
void ajouter_client_ex(Client c);
void afficher_client_ex(GtkWidget *liste);
