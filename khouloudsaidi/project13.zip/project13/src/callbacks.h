#include <gtk/gtk.h>


void
on_afficherex_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_ajouter_cl_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_quitter_ex_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);
