#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"
#include "string.h"

void
on_ajoutAdmin_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

char logs[50],passwords[50],CIN[50], role[50],tel[50];int x,jd,md,ad,jf,mf,af; 
	GtkWidget *input3;
	GtkWidget *input4;	
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
	GtkWidget *output;
	GtkWidget *combobox1;
	GtkWidget *admin;
	GtkWidget *listeview;

input3=lookup_widget(objet_graphique,"login");
combobox1=lookup_widget(objet_graphique,"choix");

input4=lookup_widget(objet_graphique,"spinbutton1");
input5=lookup_widget(objet_graphique,"spinbutton2");
input6=lookup_widget(objet_graphique,"spinbutton3");

input7=lookup_widget(objet_graphique,"spinbutton4");
input8=lookup_widget(objet_graphique,"spinbutton5");
input9=lookup_widget(objet_graphique,"spinbutton6");


admin=lookup_widget(objet_graphique, "admin");


strcpy(role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(logs,gtk_entry_get_text(GTK_ENTRY(input3)));

jd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
md=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));

jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
//sprintf(tel,"%d",tels);
ajouter_h(logs,role,jd,md,ad,jf,mf,af);

listeview = lookup_widget(admin,"table");
afficher_h(listeview,3);



}


void
on_modifierAd_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{




char logs[50],passwords[50],CIN[50], role[50],tel[50];int x,jd,md,ad,jf,mf,af; 
	GtkWidget *input3;
	GtkWidget *input4;	
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
	GtkWidget *output;
	GtkWidget *combobox1;
	GtkWidget *admin;
	GtkWidget *listeview;

input3=lookup_widget(objet_graphique,"login");
combobox1=lookup_widget(objet_graphique,"choix");

input4=lookup_widget(objet_graphique,"spinbutton1");
input5=lookup_widget(objet_graphique,"spinbutton2");
input6=lookup_widget(objet_graphique,"spinbutton3");

input7=lookup_widget(objet_graphique,"spinbutton4");
input8=lookup_widget(objet_graphique,"spinbutton5");
input9=lookup_widget(objet_graphique,"spinbutton6");


admin=lookup_widget(objet_graphique, "admin");


strcpy(role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(logs,gtk_entry_get_text(GTK_ENTRY(input3)));

jd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
md=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));

jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
//sprintf(tel,"%d",tels);
supprimer_h(logs);

ajouter_h(logs,role,jd,md,ad,jf,mf,af);
listeview = lookup_widget(admin,"table");
afficher_h(listeview,3);
}


void
on_supprimerAd_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *input1;
GtkWidget *admin;
GtkWidget *listeview;

char cin[50];

admin = lookup_widget(objet_graphique,"admin");

input1 = lookup_widget(objet_graphique,"login");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));

supprimer_h(cin);

	


listeview = lookup_widget(admin,"table");
afficher_h(listeview,3);


}


gboolean
on_HOME_focus                          (GtkWidget       *objet_graphique,
                                        GtkDirectionType  direction,
                                        gpointer         user_data)
{

}


void
on_admin_set_focus                     (GtkWindow       *window,
                                       GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *admin;
	GtkWidget *listeview;
GtkWidget *reclamationtv;
int i=0;

admin=lookup_widget(window, "admin");

listeview = lookup_widget(admin,"table");
afficher_h(listeview,1);


  
}


void
on_table_row_activated                 (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{



gint *role;
  	gchar *login;
	gchar *password;
	
gint *role6;
gint *role5;
gint *role4;

gint *role3;
gint *role2;
gint *role1;
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *input6;

	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
	GtkWidget *gestion_compte;
	GtkWidget *listeview;
        GtkWidget *supprimer_compte__;
        GtkTreeIter iter;
FILE *f;
char var[50],var1[50];
int jd, md, ad, jf, mf, af;


listeview = lookup_widget(objet_graphique,"table");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"table")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &login, 1, &password, -1);
 f = fopen("src/voyage.txt","r");
 while(fscanf(f,"%s %s %d %d %d %d %d %d",var,var1,&jd,&md,&ad,&jf,&mf,&af) != EOF)
    {
      if (strcmp(var1,login)==0)
break;
	
 
    }                                                      
 } fclose(f);
gestion_compte = lookup_widget(objet_graphique,"admin");

input1 = lookup_widget(gestion_compte,"login");
input2=lookup_widget(gestion_compte,"choix");
input3=lookup_widget(gestion_compte,"spinbutton1");

input4=lookup_widget(gestion_compte,"spinbutton2");
input5=lookup_widget(gestion_compte,"spinbutton3");
input6=lookup_widget(gestion_compte,"spinbutton4");

input7=lookup_widget(gestion_compte,"spinbutton5");
input8=lookup_widget(gestion_compte,"spinbutton6");

gtk_entry_set_text(GTK_ENTRY(input1),login);
gtk_entry_set_text(GTK_ENTRY(input2),password);





printf(" %d %d %d %d %d %d",jd,md,ad,&jf,mf,af);
gtk_spin_button_set_value(input3, jd);
gtk_spin_button_set_value(input4,md);
gtk_spin_button_set_value(input5, ad);

gtk_spin_button_set_value(input6, jf);
gtk_spin_button_set_value(input7, mf);
gtk_spin_button_set_value(input8, af);




}


void
on_sendr_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
char log[50],rec[500];	
	GtkWidget *login;
	GtkWidget *reclamation;

login=lookup_widget(objet_graphique,"entry1");
reclamation=lookup_widget(objet_graphique,"entry2");
strcpy(log,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(rec,gtk_entry_get_text(GTK_ENTRY(reclamation)));
int x;
x=ajouter_r(log,rec);
}


void
on_reclamationtv_row_activated         (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

gint *role;
  	gchar *login;
	
	
	GtkWidget *input1;
	GtkWidget *input;
	GtkWidget *gestion_compte;
	GtkWidget *listeview;
        GtkWidget *supprimer_compte__;
        GtkTreeIter iter;


listeview = lookup_widget(objet_graphique,"reclamationtv");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"reclamationtv")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &login, -1);

                                                       }
gestion_compte = lookup_widget(objet_graphique,"admin");

input1 = lookup_widget(gestion_compte,"entry1");




gtk_entry_set_text(GTK_ENTRY(input1),login);





}

