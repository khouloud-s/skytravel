#include <gtk/gtk.h>
#include<string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fonctions.h"


int ajouter_h(char log[50],char cat[50],int jd,int md,int ad,int jf,int mf,int af)
{
FILE *f;
char var[50],var1[50],var3[50];int var2;char var4[50];
f=fopen("src/voyage.txt","a+");


	
fprintf(f,"%s %s %d %d %d %d %d %d\n",log,cat,jd,md,ad,jf,mf,af);
fclose(f);	
return 1;

}

////////////////
//////////////////



void afficher_h(GtkWidget *pListView,int role)
{

enum {
TITRE,
CATEGORIE,
DATED,
DATEF,
TOGGLE_COLUMN,
N_COLUMN
};




GtkWidget *pScrollbar;
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
pListStore = gtk_tree_view_get_model(pListView);

FILE *f;char var[50],var1[50],var3[50],var4[50], var2[50];
int jd, md, ad, jf, mf, af;
f=fopen("src/voyage.txt","r");

void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *path, gpointer user_data)
{
 
    GtkTreeIter iter;
    GtkTreePath *ppath;
    gboolean boolean;
 
 
// convertir la chaine path en GtkTreePath 
 
     ppath = gtk_tree_path_new_from_string (path);
 
// convertir la valeure recuperée en GtkTreeIter  
     gtk_tree_model_get_iter (GTK_TREE_MODEL (user_data),
                           &iter,
                           ppath);
//  utiliser la variable GtkTreeIter pour acceder la valeure booleaine                           
     gtk_tree_model_get (GTK_TREE_MODEL (user_data),
                           &iter,
                           4,&boolean,
                           -1);
// changer cette valeure booleaine (! boolean )                          
     gtk_list_store_set (user_data, &iter,
                      4, !boolean,
                      -1);
 
 
}




if (pListStore == NULL) {





pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("TITRE",
pCellRenderer,
"text", TITRE,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("CATEGORIE",
pCellRenderer,
"text", CATEGORIE,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("DATED",
pCellRenderer,
"text", DATED,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("DATEF",pCellRenderer,"text", DATEF,NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);



pCellRenderer = gtk_cell_renderer_toggle_new();
pColumn=gtk_tree_view_column_new_with_attributes("select",pCellRenderer,"active", TOGGLE_COLUMN,
NULL);
g_signal_connect(G_OBJECT(pCellRenderer), "toggled", (GCallback)toggled_func, pListStore);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);	




}

pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_BOOLEAN);


while(fscanf(f,"%s %s %d %d %d %d %d %d",var,var1,&jd,&md,&ad,&jf,&mf,&af)!=EOF)
	{

sprintf(var2,"%d/%d/%d",jd,md,ad);
sprintf(var3,"%d/%d/%d",jf,mf,af);
GtkTreeIter pIter;
printf("%s",var2);
gtk_list_store_append(pListStore, &pIter);
gtk_list_store_set(pListStore, &pIter,TITRE,var,CATEGORIE,var1,DATED,var2,DATEF,var3,TOGGLE_COLUMN,FALSE,-1);



	

}

fclose(f);

gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore)); 
g_object_unref(pListStore);	
}
/////////////////
//////////////

void supprimer_h(char cin[50])
{
  FILE *f;
  FILE *f1;
char var[50],var1[50];
int jd, md, ad, jf, mf, af;
  char ch1[50], ch2[50],ch4[50],ch5[50];int ch3;

  f = fopen("src/voyage.txt","r");
  f1 = fopen("src/tompo.txt","w+");
  
    while(fscanf(f,"%s %s %d %d %d %d %d %d",var,var1,&jd,&md,&ad,&jf,&mf,&af) != EOF)
    {
      if (strcmp(var,cin)!=0)
	{

         
	
fprintf(f1,"%s %s %d %d %d %d %d %d\n",var,var1,jd,md,ad,jf,mf,af);

  	}  
    }
  

  fclose(f);
  fclose(f1);
remove("src/voyage.txt");
  rename("src/tompo.txt","src/voyage.txt");
}
////////////////
///////////////

void modifier_comptes(char login[50],char password[50],char cin[50],char tel[50],int role)
{
FILE *f,*f1;
char var[50];char var1[50];int var2;char var3[50];char var4[50];
f=fopen("src/admin.txt","r");
f1=fopen("src/tampo.txt","a+");
while(fscanf(f,"%s %s %d %s %s",var,var1,&var2,var3,var4)!=EOF)
	{
if (strcmp(var3,cin)==0)
		{
fprintf(f1,"%s %s %d %s %s \n",login,password,role,var3,tel);

	
		}
else
fprintf(f1,"%s %s %d %s %s \n",var,var1,var2,var3,var4);
	}
fclose(f1);
fclose(f);
rename("src/tampo.txt","src/admin.txt");	
}
//////////////////////////////////////
/////////////////////////////////////
void afficher_r(GtkWidget *pListView)
{

enum {
LOGIN,
RECLAMATION,
N_COLUMN
};




GtkWidget *pScrollbar;
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
pListStore = gtk_tree_view_get_model(pListView);

FILE *f;
char user[20],rec[500];
char buffer[255];
f=fopen("src/rec.txt","r");





if (pListStore == NULL) {





pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("login",
pCellRenderer,
"text", LOGIN,
NULL);

gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("RECLAMATION",
pCellRenderer,
"text", RECLAMATION,
NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);


}

pListStore = gtk_list_store_new(N_COLUMN, G_TYPE_STRING, G_TYPE_STRING);

////////////////////////
if (f == NULL)
{
	printf("Cannot open file \n");
	exit(0);
}
while (1==1)
{
	if (fgets(buffer,255, (FILE*) f)!=NULL)
	{
		int x = 0;
	while(buffer[x]!='\n' )
	{
		if (buffer[x]!=':')
		{
			user[x]=buffer[x];
			user[x+1]='\0';
		}else{
			int y=0;
			while(buffer[x+1+y]!='\n'){
			rec[y]=buffer[x+1+y];
			y++;
			}
			GtkTreeIter pIter;


			rec[y]='\0';
			rec[y+1]='\n';
			printf("%s\n", rec);
			gtk_list_store_append(pListStore, &pIter);
gtk_list_store_set(pListStore, &pIter,LOGIN,user,RECLAMATION,rec,-1); 
			break;
		}
		x++;
		}
	}else
	break;
	}
	fclose(f);
	
//////////



gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore)); 
g_object_unref(pListStore);	
}

/////////////////////
int ajouter_r(char log[50],char reclamation[500])
{
FILE *f;
f=fopen("src/adminrec.txt","a+");

fprintf(f,"%s:%s\n",log,reclamation);

fclose(f);	
return 1;

}


