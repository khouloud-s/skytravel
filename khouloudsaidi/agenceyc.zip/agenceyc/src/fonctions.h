int ajouter_h(char log[50],char cat[50],int jd,int md,int ad,int jf,int mf,int af);
void afficher_h(GtkWidget *pListView,int role);
void supprimer_h(char cin[50]);
void modifier_comptes(char login[50],char password[50],char cin[50],char tel[50],int role);
void afficher_r(GtkWidget *pListView);
int ajouter_r(char log[50],char reclamation[500]);
