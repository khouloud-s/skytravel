#include <gtk/gtk.h>


void
on_excursion_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reclamation_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouter_client_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_afficher_client_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouteragent_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifieragent_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimeragent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_entry5_insert_text                  (GtkEditable     *editable,
                                        gchar           *new_text,
                                        gint             new_text_length,
                                        gpointer         position,
                                        gpointer         user_data);

void
on_repondre_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_afficherreclagent_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_quitterexclient_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_quitterexagent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitterrecagent_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimerrec_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quitterrecadmin_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_excuclient_set_focus                (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_excuagent_set_focus                 (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reclagent_set_focus                 (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_recladmin_set_focus                 (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reclamationagent_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_excursionagent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_excursionclient_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_espaceadmin_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_afficherrecad_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_client_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_exagent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_recag_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_recad_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
