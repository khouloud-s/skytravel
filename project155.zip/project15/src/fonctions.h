int ajouter_h(char log[50],char prenoms[50],int nbre,int jd,int md,int ad,int jf,int mf,int af,char dest[50]);
void afficher_h(GtkWidget *pListView,int role);
void supprimer_h(char cin[50]);
void modifier_comptes(char login[50],char password[50],char cin[50],char tel[50],int role);
void afficher_r(GtkWidget *pListView);
int ajouter_r(char logs[50],char prenom[50],char reclamation[500],char date[50],char reponse[5000]);
void supprimer_r(char cin[50]);
