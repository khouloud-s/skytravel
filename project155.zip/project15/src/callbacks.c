#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"

void
on_excursion_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace;


GtkWidget *fenetre1;
fenetre1=lookup_widget(objet_graphique,"fenetre1");
gtk_widget_destroy(fenetre1);
espace=lookup_widget(objet_graphique,"espace");
espace=create_espace();
gtk_widget_show(espace);

}


void
on_reclamation_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace;


GtkWidget *fenetre1;
fenetre1=lookup_widget(objet_graphique,"fenetre1");
gtk_widget_destroy(fenetre1);
espace=lookup_widget(objet_graphique,"espace");
espace=create_espace();
gtk_widget_show(espace);
}


void
on_ajouter_client_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char logs[50],passwords[50],CIN[50], dest[50],tel[50],prenoms[50];int x,nbre,jd,md,ad,jf,mf,af; 
	GtkWidget *input3;
	GtkWidget *input4;	
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
        GtkWidget *input10;
        GtkWidget *input11;
	GtkWidget *output;
	GtkWidget *combobox1;
	GtkWidget *excuclient;
	GtkWidget *listeview;

input3=lookup_widget(objet_graphique,"login");
input4=lookup_widget(objet_graphique,"prenom");
combobox1=lookup_widget(objet_graphique,"choix");

input5=lookup_widget(objet_graphique,"spinbutton1");
input6=lookup_widget(objet_graphique,"spinbutton2");
input7=lookup_widget(objet_graphique,"spinbutton3");

input8=lookup_widget(objet_graphique,"spinbutton4");
input9=lookup_widget(objet_graphique,"spinbutton5");
input10=lookup_widget(objet_graphique,"spinbutton6");
input11=lookup_widget(objet_graphique,"spinbutton7");

excuclient=lookup_widget(objet_graphique, "excuclient");


strcpy(dest,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(logs,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(prenoms,gtk_entry_get_text(GTK_ENTRY(input4)));
nbre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
jd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
md=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));

jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input10));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input11));
//sprintf(tel,"%d",tels);
ajouter_h(logs,prenoms,nbre,jd,md,ad,jf,mf,af,dest);

listeview = lookup_widget(excuclient,"treeview1");
afficher_h(listeview,3);
}


void
on_afficher_client_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_ajouteragent_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char logs[50],passwords[50],CIN[50], dest[50],tel[50],prenoms[50];int x,jd,md,ad,jf,mf,nbre,af; 
	GtkWidget *input3;
	GtkWidget *input4;	
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
        GtkWidget *input10;
	GtkWidget *output;
	GtkWidget *combobox2;
	GtkWidget *excuagent;
	GtkWidget *listeview;

input3=lookup_widget(objet_graphique,"login");
input4=lookup_widget(objet_graphique,"prenom");
combobox2=lookup_widget(objet_graphique,"choix");

input5=lookup_widget(objet_graphique,"spinbutton8");
input6=lookup_widget(objet_graphique,"spinbutton9");
input7=lookup_widget(objet_graphique,"spinbutton10");

input8=lookup_widget(objet_graphique,"spinbutton11");
input9=lookup_widget(objet_graphique,"spinbutton12");
input10=lookup_widget(objet_graphique,"spinbutton13");


excuagent=lookup_widget(objet_graphique, "excuagent");


strcpy(dest,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(logs,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(prenoms,gtk_entry_get_text(GTK_ENTRY(input4)));
jd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
md=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));

jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input10));
//sprintf(tel,"%d",tels);
ajouter_h(logs,prenoms,nbre,jd,md,ad,jf,mf,af,dest);

listeview = lookup_widget(excuagent,"treeview2");
afficher_h(listeview,3);
}


void
on_modifieragent_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char logs[50],passwords[50],CIN[50],tel[50],prenoms[50], dest[50];int x,nbre,jd,md,ad,jf,mf,af; 
	GtkWidget *input3;
	GtkWidget *input4;	
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
        GtkWidget *input10;
	GtkWidget *output;
	GtkWidget *combobox2;
	GtkWidget *excuagent;
	GtkWidget *listeview;

input3=lookup_widget(objet_graphique,"login");
input4=lookup_widget(objet_graphique,"prenom");
combobox2=lookup_widget(objet_graphique,"choix");

input5=lookup_widget(objet_graphique,"spinbutton8");
input6=lookup_widget(objet_graphique,"spinbutton9");
input7=lookup_widget(objet_graphique,"spinbutton10");

input8=lookup_widget(objet_graphique,"spinbutton11");
input9=lookup_widget(objet_graphique,"spinbutton12");
input10=lookup_widget(objet_graphique,"spinbutton13");


excuagent=lookup_widget(objet_graphique, "excuagent");


strcpy(dest,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(logs,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(prenoms,gtk_entry_get_text(GTK_ENTRY(input4)));
jd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
md=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
ad=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));

jf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
mf=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
af=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input10));

//sprintf(tel,"%d",tels);
supprimer_h(logs);

ajouter_h(logs,prenoms,nbre,jd,md,ad,jf,mf,af,dest);
listeview = lookup_widget(excuagent,"treeview2");
afficher_h(listeview,3);

}


void
on_supprimeragent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *excuagent;
GtkWidget *listeview;

char cin[50];

excuagent= lookup_widget(objet_graphique,"excuagent");

input1 = lookup_widget(objet_graphique,"login");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));

supprimer_h(cin);

	


listeview = lookup_widget(excuagent,"treeview2");
afficher_h(listeview,3);

}


void
on_entry5_insert_text                  (GtkEditable     *editable,
                                        gchar           *new_text,
                                        gint             new_text_length,
                                        gpointer         position,
                                        gpointer         user_data)
{

}


void
on_repondre_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


char logs[50],prenom[50],CIN[50],reclamation[5000],date[50],reponse[5000];int x; 
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
        GtkWidget *input5;
	GtkWidget *output;
	
	GtkWidget *reclagent;
	GtkWidget *listeview;

input1=lookup_widget(objet_graphique,"login");
input2=lookup_widget(objet_graphique,"prenom");
input3=lookup_widget(objet_graphique,"reclamation");
input4=lookup_widget(objet_graphique,"date");
input5=lookup_widget(objet_graphique,"reponse");



reclagent=lookup_widget(objet_graphique, "reclagent");



strcpy(logs,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(reclamation,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(date,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(reponse,gtk_entry_get_text(GTK_ENTRY(input5)));


//sprintf(tel,"%d",tels);
supprimer_r(logs);

ajouter_r(logs,prenom,reclamation,date,reponse);
listeview = lookup_widget(reclagent,"treeview3");
afficher_r(listeview);
}


void
on_afficherreclagent_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_treeview1_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gint *role;
  	gchar *login;
	gchar *prenom;
	gchar *choix;
gint *role6;
gint *role5;
gint *role4;

gint *role3;
gint *role2;
gint *role1;
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *input6;

	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
        GtkWidget *input10;
	GtkWidget *gestion_compte;
	GtkWidget *listeview;
        GtkWidget *supprimer_compte__;
        GtkTreeIter iter;
FILE *f;
char var[50],var1[50],var2[50];
int jd, md, ad, jf, mf, af,nbre;


listeview = lookup_widget(objet_graphique,"treeview1");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeview1")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &login, 1, &prenom, -1);
 /*f = fopen("src/excursion.txt","r");
 while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d",var,var1,var2,&nbre,&jd,&md,&ad,&jf,&mf,&af) != EOF)
    {
      if ((strcmp(var1,nom)==0)&&(strcmp(var2,prenom)==0))
     
break;
	
 
    }                                                      
 } fclose(f);*/
gestion_compte = lookup_widget(objet_graphique,"excuclient");

input1 = lookup_widget(gestion_compte,"login");
input2=lookup_widget(gestion_compte,"prenom");

input3=lookup_widget(gestion_compte,"spinbutton1");

input4=lookup_widget(gestion_compte,"spinbutton2");
input5=lookup_widget(gestion_compte,"spinbutton3");
input6=lookup_widget(gestion_compte,"spinbutton4");

input7=lookup_widget(gestion_compte,"spinbutton5");
input8=lookup_widget(gestion_compte,"spinbutton6");
input9=lookup_widget(gestion_compte,"spinbutton7");
input10=lookup_widget(gestion_compte,"choix");
gtk_entry_set_text(GTK_ENTRY(input1),login);
gtk_entry_set_text(GTK_ENTRY(input2),prenom);
gtk_entry_set_text(GTK_ENTRY(input10),choix);




//printf(" %d %d %d %d %d %d %d",nbre,jd,md,ad,jf,mf,af);
gtk_spin_button_set_value(input3, nbre);
gtk_spin_button_set_value(input4, jd);
gtk_spin_button_set_value(input5,md);
gtk_spin_button_set_value(input6, ad);

gtk_spin_button_set_value(input7, jf);
gtk_spin_button_set_value(input8, mf);
gtk_spin_button_set_value(input9, af);


}
}

void
on_quitterexclient_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget*excuclient;
excuclient=lookup_widget(objet_graphique,"excuclient");
gtk_widget_destroy(excuclient);
}


void
on_treeview2_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gint *role;
  	gchar *login;
	gchar *prenom;
        gchar *choix;
	
gint *role6;
gint *role5;
gint *role4;

gint *role3;
gint *role2;
gint *role1;
	GtkWidget *input1;
	GtkWidget *input2;	
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *input6;

	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
        GtkWidget *input10;
	GtkWidget *gestion_compte;
	GtkWidget *listeview;
        GtkWidget *supprimer_compte__;
        GtkTreeIter iter;
FILE *f;
char var[50],var1[50],var2[50];
int jd, md, ad, jf, mf, af,nbre;


listeview = lookup_widget(objet_graphique,"treeview2");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeview2")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &login, 1, &prenom, -1);
 f = fopen("src/excursion.txt","r");
 while(fscanf(f,"%s %s %s %d %d %d %d %d %d %d",var,var1,var2,&nbre,&jd,&md,&ad,&jf,&mf,&af) != EOF)
    {
      if (strcmp(var1,login)==0)
     
break;
	
 
    }                                                      
 } fclose(f);
gestion_compte = lookup_widget(objet_graphique,"excuagent");

input1 = lookup_widget(gestion_compte,"login");
input2=lookup_widget(gestion_compte,"prenom");

input3=lookup_widget(gestion_compte,"spinbutton1");

input4=lookup_widget(gestion_compte,"spinbutton2");
input5=lookup_widget(gestion_compte,"spinbutton3");
input6=lookup_widget(gestion_compte,"spinbutton4");

input7=lookup_widget(gestion_compte,"spinbutton5");
input8=lookup_widget(gestion_compte,"spinbutton6");
input9=lookup_widget(gestion_compte,"spinbutton7");
input10=lookup_widget(gestion_compte,"choix");
gtk_entry_set_text(GTK_ENTRY(input1),login);
gtk_entry_set_text(GTK_ENTRY(input2),prenom);
gtk_entry_set_text(GTK_ENTRY(input10),choix);




//printf(" %d %d %d %d %d %d %d",nbre,jd,md,ad,jf,mf,af);
gtk_spin_button_set_value(input3, nbre);
gtk_spin_button_set_value(input4, jd);
gtk_spin_button_set_value(input5,md);
gtk_spin_button_set_value(input6, ad);

gtk_spin_button_set_value(input7, jf);
gtk_spin_button_set_value(input8, mf);
gtk_spin_button_set_value(input9, af);
}


void
on_quitterexagent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget*excuagent;
excuagent=lookup_widget(objet_graphique,"excuagent");
gtk_widget_destroy(excuagent);
}


void
on_quitterrecagent_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget*reclagent;
reclagent=lookup_widget(objet_graphique,"reclagent");
gtk_widget_destroy(reclagent);
}


void
on_supprimerrec_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *recladmin;
GtkWidget *listeview;

char cin[50];

recladmin = lookup_widget(objet_graphique,"recladmin");

input1 = lookup_widget(objet_graphique,"login");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input1)));

supprimer_r(cin);

	


listeview = lookup_widget(recladmin,"treeview4");
afficher_r(listeview);
}


void
on_quitterrecadmin_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget*recladmin;
recladmin=lookup_widget(objet_graphique,"recladmin");
gtk_widget_destroy(recladmin);
}


void
on_treeview3_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gint *role;
  	
	gchar *login;
	gchar *prenom;
        gchar *reclamation;
        gchar *date;
        gchar *reponse;
gint *role6;
gint *role5;
gint *role4;

gint *role3;
gint *role2;
gint *role1;
        GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
        GtkWidget *input4;
        GtkWidget *input5;
	GtkWidget *gestion_compte;
	GtkWidget *listeview;
        GtkWidget *supprimer_compte__;
        GtkTreeIter iter;
FILE *f;
char var[50],var1[50],var2[5000],var3[5000],var4[50];


listeview = lookup_widget(objet_graphique,"treeview3");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeview3")));
 

   if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &login, 1, &prenom,2,&reclamation,3,&date,4,&reponse, -1);
 
 f = fopen("src/reclamation.txt","r");
 while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var4,var3) != EOF)
    {
      if (strcmp(var,login)==0)
break;
	
 
    }                                                      
 } fclose(f);

gestion_compte = lookup_widget(objet_graphique,"reclagent");
input1 = lookup_widget(gestion_compte,"login");
input2 = lookup_widget(gestion_compte,"prenom");
input3 = lookup_widget(gestion_compte,"reclamation");
input4 = lookup_widget(gestion_compte,"date");
input5 = lookup_widget(gestion_compte,"reponse");
gtk_entry_set_text(GTK_ENTRY(input1),login);
gtk_entry_set_text(GTK_ENTRY(input2),prenom);
gtk_entry_set_text(GTK_ENTRY(input3),reclamation);
gtk_entry_set_text(GTK_ENTRY(input4),date);
gtk_entry_set_text(GTK_ENTRY(input5),reponse);



}


void
on_treeview4_row_activated             (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gint *role;
  	gchar *reponse;
	gchar *login;
	gchar *prenom;
gint *role6;
gint *role5;
gint *role4;

gint *role3;
gint *role2;
gint *role1;
	GtkWidget *input1;
	
	GtkWidget *gestion_compte;
	GtkWidget *listeview;
        GtkWidget *supprimer_compte__;
        GtkTreeIter iter;
FILE *f;
char var[50],var1[50],var2[5000],var3[5000],var4[50];


listeview = lookup_widget(objet_graphique,"treeview4");

GtkTreeModel *model = gtk_tree_view_get_model (GTK_TREE_VIEW(lookup_widget(objet_graphique,"treeview4")));
 

 if (gtk_tree_model_get_iter(model, &iter, path)) {
      gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &login, 1, &prenom, -1);
 f = fopen("src/reclamation.txt","r");
 while(fscanf(f,"%s %s %s %s %s",var,var1,var2,var4,var3) != EOF)
    {
      if (strcmp(var1,login)==0)
     
break;
	
 
    }                                                      
 } fclose(f);
gestion_compte = lookup_widget(objet_graphique,"recladmin");
input1=lookup_widget(gestion_compte,"login");
gtk_entry_set_text(GTK_ENTRY(input1),login);


}


void
on_excuclient_set_focus                (GtkWindow       *window,
                                       GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *excuclient;
	GtkWidget *listeview;

int i=0;

excuclient=lookup_widget(window, "excuclient");

listeview = lookup_widget(excuclient,"treeview1");
afficher_h(listeview,3);

}


void
on_excuagent_set_focus                 (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *excuagent;
	GtkWidget *listeview;

int i=0;

excuagent=lookup_widget(window, "excuagent");

listeview = lookup_widget(excuagent,"treeview2");
afficher_h(listeview,2);

}


void
on_reclagent_set_focus                 (GtkWindow       *window,
                                       GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reclagent;
	GtkWidget *listeview;

int i=0;

reclagent=lookup_widget(window, "reclagent");

listeview = lookup_widget(reclagent,"treeview3");
afficher_r(listeview);

}


void
on_recladmin_set_focus                 (GtkWindow       *window,
                                        GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *recladmin;
	GtkWidget *listeview;

int i=0;

recladmin=lookup_widget(window, "recladmin");

listeview = lookup_widget(recladmin,"treeview4");
afficher_r(listeview);
}
void
on_reclamationagent_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace;


GtkWidget *reclagent;
espace=lookup_widget(objet_graphique,"espace");
gtk_widget_destroy(espace);

reclagent=lookup_widget(objet_graphique,"reclagent");
reclagent=create_reclagent();
gtk_widget_show(reclagent);
}

void
on_excursionagent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace;


GtkWidget *excuagent;
espace=lookup_widget(objet_graphique,"espace");
gtk_widget_destroy(espace);

excuagent=lookup_widget(objet_graphique,"excuagent");
excuagent=create_excuagent();
gtk_widget_show(excuagent);

}

void
on_excursionclient_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace;


GtkWidget *excuclient;
espace=lookup_widget(objet_graphique,"espace");
gtk_widget_destroy(espace);

excuclient=lookup_widget(objet_graphique,"excuclient");
excuclient=create_excuclient();
gtk_widget_show(excuclient);
}

void
on_espaceadmin_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace;


GtkWidget *recladmin;
espace=lookup_widget(objet_graphique,"espace");
gtk_widget_destroy(espace);

recladmin=lookup_widget(objet_graphique,"recladmin");
recladmin=create_recladmin();
gtk_widget_show(recladmin);
}


void
on_afficherrecad_clicked               (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
}


void
on_retour_client_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *excuclient ;
GtkWidget *espace;

excuclient=lookup_widget(objet_graphique,"excuclient");

gtk_widget_destroy(excuclient);
espace=create_espace();

gtk_widget_show(espace);
}


void
on_retour_exagent_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *excuagent ;
GtkWidget *espace;

excuagent=lookup_widget(objet_graphique,"excuagent");

gtk_widget_destroy(excuagent);
espace=create_espace();

gtk_widget_show(espace);
}


void
on_retour_recag_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *reclagent ;
GtkWidget *espace;

reclagent=lookup_widget(objet_graphique,"reclagent");

gtk_widget_destroy(reclagent);
espace=create_espace();

gtk_widget_show(espace);
}


void
on_retour_recad_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *recladmin ;
GtkWidget *espace;

recladmin=lookup_widget(objet_graphique,"recladmin");

gtk_widget_destroy(recladmin);
espace=create_espace();

gtk_widget_show(espace);
}

